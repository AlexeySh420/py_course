from flask import Flask
from board import pages, tweets, database
from dotenv import load_dotenv


load_dotenv()


def create_app(test_config=None):
    # create and configure the app
    app = Flask(__name__)
    app.config.from_prefixed_env()

    database.init_app(app)

    # a simple page that says hello
    app.register_blueprint(pages.bp)
    app.register_blueprint(tweets.bp)

    return app
