from flask import Flask

app = Flask(__name__)


# http://127.0.0.1:5000/ -- get 200
# http://127.0.0.1:5000/map/
# http://127.0.0.1:5000/about/
# http://127.0.0.1:5000/contact/
# http://127.0.0.1:5000/lol/


@app.route("/")
def index_page():
    return "<p>Страница по умолчанию!</p>"


@app.route("/about/")
def about():
    return "<p>Мы +++ очень крутые...</p>"


@app.route("/contact/")
def contact():
    return "<p>Форма связи с нами</p>"


@app.route("/map/")
def home():
    return "<p>Карта как до нас доехать.</p>"


@app.route("/lol/")
def lol():
    return """
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        
        
            <title>HTML for Beginners – HTML Basics With Code Examples</title>
        
        <meta name="HandheldFriendly" content="True">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin="">
        <link rel="preload" as="style" onload="this.onload=null;this.rel='stylesheet'" href="https://fonts.googleapis.com/css2?family=Lato:ital,wght@0,300;0,400;0,700;1,400&family=Roboto+Mono:wght@400;700&display=swap">
        

        
        
    <link rel="preload" as="style" onload="this.onload=null;this.rel='stylesheet'" href="https://cdn.freecodecamp.org/news-assets/prism/1.29.0/themes/prism.min.css">
<noscript>
  <link rel="stylesheet" href="https://cdn.freecodecamp.org/news-assets/prism/1.29.0/themes/prism.min.css">
</noscript>
<link rel="preload" as="style" onload="this.onload=null;this.rel='stylesheet'" href="https://cdn.freecodecamp.org/news-assets/prism/1.29.0/plugins/unescaped-markup/prism-unescaped-markup.min.css">
<noscript>
  <link rel="stylesheet" href="https://cdn.freecodecamp.org/news-assets/prism/1.29.0/plugins/unescaped-markup/prism-unescaped-markup.min.css">
</noscript>

<script defer="" src="https://cdn.freecodecamp.org/news-assets/prism/1.29.0/components/prism-core.min.js"></script>
<script defer="" src="https://cdn.freecodecamp.org/news-assets/prism/1.29.0/plugins/autoloader/prism-autoloader.min.js"></script>



        
        <link rel="preload" as="style" onload="this.onload=null;this.rel='stylesheet'" href="/news/assets/css/global-5a272ab5e0.css">
        <link rel="stylesheet" type="text/css" href="/news/assets/css/screen-73acb3583e.css">
        <link rel="stylesheet" type="text/css" href="/news/assets/css/search-bar-124f5f949c.css">

        
        <script defer="" src="https://cdn.freecodecamp.org/news-assets/algolia/algoliasearch-3-33-0/algoliasearch.min.js"></script>
        <script defer="" src="https://cdn.freecodecamp.org/news-assets/algolia/autocomplete-0-36-0/autocomplete.min.js"></script>

        
        <script defer="" src="https://cdn.freecodecamp.org/news-assets/dayjs/1.10.4/dayjs.min.js"></script>
        <script defer="" src="https://cdn.freecodecamp.org/news-assets/dayjs/1.10.4/localizedFormat.min.js"></script>
        <script defer="" src="https://cdn.freecodecamp.org/news-assets/dayjs/1.10.4/relativeTime.min.js"></script>

        
        
            <script defer="" src="https://cdn.freecodecamp.org/news-assets/dayjs/1.10.4/locale/en.min.js"></script>
        

        
        <script>let client,index;document.addEventListener("DOMContentLoaded",(()=>{client=algoliasearch("QMJYL5WYTI","89770b24481654192d7a5c402c6ad9a0"),index=client.initIndex("news")})),document.addEventListener("DOMContentLoaded",(()=>{const e=window.screen.width,t=window.screen.height,n=e>=767&&t>=768?8:5,o=document.getElementById("search-form"),s=document.getElementById("search-input"),a=document.getElementById("dropdown-container");let i,d,c;s.addEventListener("input",(e=>{i=e.target.value})),o.addEventListener("submit",(e=>{e.preventDefault(),function(){if(d=document.getElementsByClassName("aa-cursor")[0],d&&i){const e=d.querySelector("a").href;window.location.assign(e)}else!d&&i&&c&&window.location.assign(`https://www.freecodecamp.org/news/search?query=${i}`)}()}));const l=autocomplete("#search-input",{hint:!1,keyboardShortcuts:["s",191],openOnFocus:!0,appendTo:a,debug:!0},[{source:autocomplete.sources.hits(index,{hitsPerPage:n}),debounce:250,templates:{suggestion:e=>(c=!0,`\n            <a href="${e.url}">\n              <div class="algolia-result">\n                <span>${e._highlightResult.title.value}</span>\n              </div>\n            </a>\n          `),empty:()=>(c=!1,'\n            <div class="aa-suggestion footer-suggestion no-hits-footer">\n              <div class="algolia-result">\n                <span>\n                  No results found\n                </span>\n              </div>\n            </div>\n          '),footer:e=>{if(!e.isEmpty)return`\n              <div class="aa-suggestion footer-suggestion">\n                <a id="algolia-footer-selector" href="https://www.freecodecamp.org/news/search?query=${i}">\n                  <div class="algolia-result algolia-footer">\n                    See all results for ${i}\n                  </div>\n                </a>\n              </div>\n            `}}}]).on("autocomplete:selected",((e,t,n,o)=>{d=t?t.url:`https://www.freecodecamp.org/news/search?query=${i}`,"click"!==o.selectionMethod&&"tabKey"!==o.selectionMethod&&c&&window.location.assign(d)}));document.addEventListener("click",(e=>{e.target!==s&&l.autocomplete.close()}))})),document.addEventListener("DOMContentLoaded",(()=>{dayjs.extend(dayjs_plugin_localizedFormat),dayjs.extend(dayjs_plugin_relativeTime),dayjs.locale("en")}));const isAuthenticated=document.cookie.split(";").some((e=>e.trim().startsWith("jwt_access_token="))),isDonor=document.cookie.split(";").some((e=>e.trim().startsWith("isDonor=true")));</script>

        
            <script src="https://securepubads.g.doubleclick.net/tag/js/gpt.js" crossorigin="anonymous" async=""></script>
        

        
        
    
        
            <script>
document.addEventListener('DOMContentLoaded', function() {
    var sidebar = document.querySelector('.sidebar');
    var isSideBarDisplayed = window.getComputedStyle(sidebar).display !== 'none';
    function prepareAdSlot(elementId) {
        // Get the element by ID
        const targetElement = document.getElementById(elementId);

        // Ensure the element exists before proceeding
        if (!targetElement) {
            console.error(`Element with ID ${elementId} not found`);
            return;
        }

        const parentElement = targetElement.parentElement;
        // Change the background color of the parent element

        if (parentElement) {
            console.log(elementId)

            if (elementId === 'gam-ad-bottom' ) {
                parentElement.style.backgroundColor = '#eeeef0';
                if(getComputedStyle(parentElement).visibility === 'hidden') {
                    parentElement.style.visibility = 'inherit'; 
                }
            }

            // Get the sibling elements
            const siblingElements = parentElement.children;

            for (let i = 0; i < siblingElements.length; i++) {
                const sibling = siblingElements[i];

                // Skip the element itself
                if (sibling === targetElement) continue;

                // Log the sibling or perform any other action
                console.log('Found sibling:', sibling);

                // Check visibility
                if(getComputedStyle(sibling).visibility === 'hidden') {
                    sibling.style.visibility = 'inherit'; 
                }

                // Check if display is 'none', then change it to 'block'
                if (getComputedStyle(sibling).display === 'none') {
                    sibling.style.display = 'block'; 
                }
            }
        } else {
            console.warn('No parent element found');
        }
    }

    
    window.googletag = window.googletag || {cmd: []};
    googletag.cmd.push(function() {

        if(isSideBarDisplayed){
            var sidebarHeight = sidebar.offsetHeight;
            var adTextSideBarHeight = 0;
            var sideBarAdContainert = 600 + 17;
        
            var styles = window.getComputedStyle(sidebar);
            var avaiableSideAdSpace = sidebarHeight - adTextSideBarHeight - parseFloat(styles.paddingTop) - parseFloat(styles.paddingBottom);
            var numSideElements = Math.floor(avaiableSideAdSpace / sideBarAdContainert);
            for (var i = 0; i < numSideElements; i++) {
                // container element
                var containerElement = document.createElement('div');
                containerElement.classList.add('ad-wrapper');

                //text element
                var textElement = document.createElement('div');
                textElement.classList.add('ad-text');
                textElement.innerText = localizedAdText;

                // ad element
                var adElement = document.createElement('div');
                var sideAdElementId = 'side-gam-ad-' + i;
                adElement.id = sideAdElementId;
                adElement.classList.add('side-bar-ad-slot');

                // finalize setup
                containerElement.appendChild(textElement);
                containerElement.appendChild(adElement);
                sidebar.appendChild(containerElement);
                googletag.defineSlot('/23075930536/post-side', [[292, 30], [240, 400], [300, 75], [216, 54], [250, 360], [300, 50], 'fluid', [300, 31], [120, 20], [300, 250], [120, 30], [180, 150], [200, 446], [168, 42], [200, 200], [160, 600], [120, 90], [125, 125], [240, 133], [120, 60], [1, 1], [120, 240], [220, 90], [216, 36], [250, 250], [168, 28], [234, 60], [120, 600], [300, 600], [88, 31], [300, 100]], sideAdElementId).addService(googletag.pubads());
            }
        }

        // Define bottom ad
        googletag.defineSlot('/23075930536/post-bottom', ['fluid'], 'gam-ad-bottom').addService(googletag.pubads());

        // Enable lazy loading with default settings.
        googletag.pubads().enableLazyLoad();

        googletag.pubads().addEventListener("slotRequested", (event) => {
            console.log(`Slot ${event.slot.getSlotElementId()} fetched`);
        });

        googletag.pubads().addEventListener("slotOnload", (event) => {
            const elementId = event.slot.getSlotElementId();
            prepareAdSlot(elementId);
            console.log(`Slot ${event.slot.getSlotElementId()} rendered`);
        });

        googletag.pubads().enableSingleRequest();
        googletag.enableServices();


        // Trigger lazy loading
        googletag.display('gam-ad-bottom');

    });
});
</script>

        
    


        
            <script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-5D6RKKP');</script>

        
        
        
        
    
        
    


        
        
        

        
        

        <link rel="icon" href="https://cdn.freecodecamp.org/universal/favicons/favicon.ico" type="image/png">
        
        
            <link rel="canonical" href="https://www.freecodecamp.org/news/introduction-to-html-basics/">
        
        <meta name="referrer" content="no-referrer-when-downgrade">

        

        
    <meta name="description" content="Welcome to the exciting world of web development! In this beginner&#39;s guide, you will learn the fundamentals of HTML, the backbone of every web page. Imagine a tree: its roots anchor and nourish the entire plant. Similarly, HTML, the root of web devel...">

    
    <meta property="og:site_name" content="freeCodeCamp.org">
    <meta property="og:type" content="article">
    <meta property="og:title" content="HTML for Beginners – HTML Basics With Code Examples">
    
        <meta property="og:description" content="Welcome to the exciting world of web development! In this beginner&#39;s guide, you will learn the fundamentals of HTML, the backbone of every web page. Imagine a tree: its roots anchor and nourish the entire plant. Similarly, HTML, the root of web devel...">
    
    <meta property="og:url" content="https://www.freecodecamp.org/news/introduction-to-html-basics/">
    <meta property="og:image" content="https://www.freecodecamp.org/news/content/images/2024/05/cover-img.jpg">
    <meta property="article:published_time" content="2024-05-07T19:45:50.000Z">
    <meta property="article:modified_time" content="2024-10-09T16:58:56.146Z">
    
        <meta property="article:tag" content="HTML">
    
    <meta property="article:publisher" content="https://www.facebook.com/freecodecamp">
    
        <meta property="article:author" content="nuelcas">
    

    
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="HTML for Beginners – HTML Basics With Code Examples">
    
        <meta name="twitter:description" content="Welcome to the exciting world of web development! In this beginner&#39;s guide, you will learn the fundamentals of HTML, the backbone of every web page. Imagine a tree: its roots anchor and nourish the entire plant. Similarly, HTML, the root of web devel...">
    
    <meta name="twitter:url" content="https://www.freecodecamp.org/news/introduction-to-html-basics/">
    <meta name="twitter:image" content="https://www.freecodecamp.org/news/content/images/2024/05/cover-img.jpg">
    <meta name="twitter:label1" content="Written by">
    <meta name="twitter:data1" content="Casmir Onyekani">
    <meta name="twitter:label2" content="Filed under">
    <meta name="twitter:data2" content="HTML">
    <meta name="twitter:site" content="@freecodecamp">
    
        <meta name="twitter:creator" content="@casweb_dev">
    

    <meta property="og:image:width" content="600">
    <meta property="og:image:height" content="400">


        
    <script type="application/ld+json">{
	"@context": "https://schema.org",
	"@type": "Article",
	"publisher": {
		"@type": "Organization",
		"name": "freeCodeCamp.org",
		"url": "https://www.freecodecamp.org/news/",
		"logo": {
			"@type": "ImageObject",
			"url": "https://cdn.freecodecamp.org/platform/universal/fcc_primary.svg",
			"width": 2100,
			"height": 240
		}
	},
	"image": {
		"@type": "ImageObject",
		"url": "https://www.freecodecamp.org/news/content/images/2024/05/cover-img.jpg",
		"width": 600,
		"height": 400
	},
	"url": "https://www.freecodecamp.org/news/introduction-to-html-basics/",
	"mainEntityOfPage": {
		"@type": "WebPage",
		"@id": "https://www.freecodecamp.org/news/"
	},
	"datePublished": "2024-05-07T19:45:50.000Z",
	"dateModified": "2024-10-09T16:58:56.146Z",
	"keywords": "HTML",
	"description": "Welcome to the exciting world of web development! In this beginner&#x27;s guide, you will learn the fundamentals of HTML, the backbone of every web page.\nImagine a tree: its roots anchor and nourish the entire plant. Similarly, HTML, the root of web devel...",
	"headline": "HTML for Beginners – HTML Basics With Code Examples",
	"author": {
		"@type": "Person",
		"name": "Casmir Onyekani",
		"url": "https://www.freecodecamp.org/news/author/Casmir/",
		"sameAs": [
			"https://casmir.netlify.app/",
			"https://www.facebook.com/nuelcas",
			"https://x.com/casweb_dev"
		],
		"image": {
			"@type": "ImageObject",
			"url": "https://cdn.hashnode.com/res/hashnode/image/upload/v1729274510229/f4288580-9987-4eed-b3e2-5778f8b30671.jpeg?w=500&h=500&fit=crop&crop=entropy&auto=compress,format&format=webp",
			"width": 3448,
			"height": 3772
		}
	}
}</script>


        <meta name="generator" content="Eleventy">
        <link rel="alternate" type="application/rss+xml" title="freeCodeCamp.org" href="https://www.freecodecamp.org/news/rss/">

        
        

        
  <meta name="x-fcc-source" data-test-label="x-fcc-source" content="Hashnode">

    </head>

    
        <body class="home-template">
    

    
        <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-5D6RKKP" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>

    

        <div class="site-wrapper">
            <nav class="site-nav nav-padding">
    <div class="site-nav-left">
        
<form id="search-form" data-test-label="search-bar">
    <div role="search" class="searchbox__wrapper">
        <label class="fcc_sr_only" for="search-input">
            Search
        </label>
        <input type="search" placeholder="
    Search 11,800+ news articles, tutorials, and books
" id="search-input">
        <button type="submit" class="ais-SearchBox-submit">
            <svg class="ais-SearchBox-submitIcon" xmlns="https://www.w3.org/2000/svg" width="10" height="10" viewBox="0 0 40 40">
    <path d="M26.804 29.01c-2.832 2.34-6.465 3.746-10.426 3.746C7.333 32.756 0 25.424 0 16.378 0 7.333 7.333 0 16.378 0c9.046 0 16.378 7.333 16.378 16.378 0 3.96-1.406 7.594-3.746 10.426l10.534 10.534c.607.607.61 1.59-.004 2.202-.61.61-1.597.61-2.202.004L26.804 29.01zm-10.426.627c7.323 0 13.26-5.936 13.26-13.26 0-7.32-5.937-13.257-13.26-13.257C9.056 3.12 3.12 9.056 3.12 16.378c0 7.323 5.936 13.26 13.258 13.26z"></path>
</svg>

            <span class="fcc_sr_only">Submit your search query</span>
        </button>
        <div id="dropdown-container"></div>
    </div>
</form>

    </div>
    <div class="site-nav-middle">
        <a class="site-nav-logo" href="https://www.freecodecamp.org/news/" data-test-label="site-nav-logo"><img src="https://cdn.freecodecamp.org/platform/universal/fcc_primary.svg" alt="freeCodeCamp.org"></a>
    </div>
    <div class="site-nav-right">
        <div class="nav-group">
            <a class="nav-forum" id="nav-forum" rel="noopener noreferrer" href="https://forum.freecodecamp.org/" target="_blank" data-test-label="forum-button">Forum</a>
            <a class="toggle-button-nav" id="nav-donate" rel="noopener noreferrer" href="https://www.freecodecamp.org/donate/" target="_blank" data-test-label="donate-button">Donate</a>
        </div>
    </div>
</nav>


            
            <a class="banner" id="banner" data-test-label="banner" rel="noopener noreferrer" target="_blank">
    <p id="banner-text"></p>
</a>


    
    <script>document.addEventListener("DOMContentLoaded",(()=>{const e=document.getElementById("banner"),t=document.getElementById("banner-text");if(isAuthenticated){t.innerHTML=isDonor?"Thank you for supporting freeCodeCamp through <span>your donations</span>.":"Support our charity and our mission. <span>Donate to freeCodeCamp.org</span>.",e.href=isDonor?"https://www.freecodecamp.org/news/how-to-donate-to-free-code-camp/":"https://www.freecodecamp.org/donate";const o=isDonor?"donor":"authenticated";e.setAttribute("text-variation",o)}else t.innerHTML="Learn to code — <span>free 3,000-hour curriculum</span>",e.href="https://www.freecodecamp.org/",e.setAttribute("text-variation","default")}));</script>


            <div id="error-message"></div>

            
    <main id="site-main" class="post-template site-main outer">
        <div class="inner ad-layout">
            <article class="post-full post">
                <header class="post-full-header">
                    <section class="post-full-meta">
                        <time class="post-full-meta-date" data-test-label="post-full-meta-date" datetime="2024-05-07T19:45:50.000Z">
                            May 7, 2024
                        </time>
                        
                            <span class="date-divider">/</span>
                            <a dir="ltr" href="/news/tag/html/">
                                #HTML
                            </a>
                        
                    </section>
                    <h1 class="post-full-title" data-test-label="post-full-title">HTML for Beginners – HTML Basics With Code Examples</h1>
                </header>
                
                    <div class="post-full-author-header" data-test-label="author-header-no-bio">
                        
                            
    
    
    

    <section class="author-card" data-test-label="author-card">
        
            
    <img srcset="https://cdn.hashnode.com/res/hashnode/image/upload/v1729274510229/f4288580-9987-4eed-b3e2-5778f8b30671.jpeg?w=500&h=500&fit=crop&crop=entropy&auto=compress,format&format=webp 60w" sizes="60px" src="https://cdn.hashnode.com/res/hashnode/image/upload/v1729274510229/f4288580-9987-4eed-b3e2-5778f8b30671.jpeg?w=500&h=500&fit=crop&crop=entropy&auto=compress,format&format=webp" class="author-profile-image" alt="Casmir Onyekani" width="3448" height="3772" onerror="this.style.display='none'" data-test-label="profile-image">
  
        

        <section class="author-card-content author-card-content-no-bio">
            <span class="author-card-name">
                <a href="/news/author/Casmir/" data-test-label="profile-link">
                    
                        Casmir Onyekani
                    
                </a>
            </span>
            
        </section>
    </section>

                        
                    </div>
                
                <figure class="post-full-image">
                    
    <picture>
      <source media="(max-width: 700px)" sizes="1px" srcset="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7 1w">
      <source media="(min-width: 701px)" sizes="(max-width: 800px) 400px, (max-width: 1170px) 700px, 1400px" srcset="https://www.freecodecamp.org/news/content/images/size/w300/2024/05/cover-img.jpg 300w, https://www.freecodecamp.org/news/content/images/size/w600/2024/05/cover-img.jpg 600w, https://www.freecodecamp.org/news/content/images/size/w1000/2024/05/cover-img.jpg 1000w, https://www.freecodecamp.org/news/content/images/size/w2000/2024/05/cover-img.jpg 2000w">
      <img onerror="this.style.display='none'" src="https://www.freecodecamp.org/news/content/images/size/w2000/2024/05/cover-img.jpg" alt="HTML for Beginners – HTML Basics With Code Examples" ,="" width="600" height="400" data-test-label="feature-image">
    </picture>
  
                </figure>
                <section class="post-full-content">
                    <div class="post-and-sidebar">
                        <section class="post-content " data-test-label="post-content">
                            
<p>Welcome to the exciting world of web development! In this beginner's guide, you will learn the fundamentals of HTML, the backbone of every web page.</p>
<p>Imagine a tree: its roots anchor and nourish the entire plant. Similarly, HTML, the root of web development, provides the foundation for every webpage.</p>
<p>Understanding HTML's role is like grasping a tree's roots, it forms the fundamental basis for comprehending how web pages come to life.</p>
<p>By the end of this tutorial, you'll be equipped with the knowledge to kick-start your coding journey.</p>
<h2 id="heading-table-of-contents">Table of Contents</h2>
<ul>
<li><p><a class="post-section-overview" href="#heading-what-is-html">What is HTML?</a></p>
</li>
<li><p><a class="post-section-overview" href="#heading-basic-structure-of-an-html-document">Basic Structure of an HTML Document</a></p>
</li>
<li><p><a class="post-section-overview" href="#heading-comments">Comments</a></p>
</li>
<li><p><a class="post-section-overview" href="#heading-tags-and-elements">Tags and Elements</a></p>
</li>
<li><p><a class="post-section-overview" href="#heading-html-attributes">HTML Attributes</a></p>
</li>
<li><p><a class="post-section-overview" href="#heading-html-multimedia">HTML Multimedia</a></p>
</li>
<li><p><a class="post-section-overview" href="#heading-best-practices">Best Practices</a></p>
</li>
</ul>
<h2 id="heading-what-is-html">What is HTML?</h2>
<p>HTML, which stands for Hypertext Markup Language, is the standard language used for creating and designing the structure of a web page. It allows you to organize content on your website, define its structure, and establish the relationships between different elements.</p>
<h2 id="heading-basic-structure-of-an-html-document">Basic Structure of an HTML Document</h2>
<p>An HTML document follows a specific structure that acts as the foundation for your web page:</p>
<pre><code class="lang-html"><span class="hljs-meta">&lt;!DOCTYPE <span class="hljs-meta-keyword">html</span>&gt;</span>
<span class="hljs-tag">&lt;<span class="hljs-name">html</span> <span class="hljs-attr">lang</span>=<span class="hljs-string">"en"</span>&gt;</span>
<span class="hljs-tag">&lt;<span class="hljs-name">head</span>&gt;</span>
  <span class="hljs-tag">&lt;<span class="hljs-name">meta</span> <span class="hljs-attr">charset</span>=<span class="hljs-string">"UTF-8"</span>&gt;</span>
  <span class="hljs-tag">&lt;<span class="hljs-name">meta</span> <span class="hljs-attr">name</span>=<span class="hljs-string">"viewport"</span> <span class="hljs-attr">content</span>=<span class="hljs-string">"width=device-width, initial-scale=1.0"</span>&gt;</span>
  <span class="hljs-tag">&lt;<span class="hljs-name">title</span>&gt;</span>Document<span class="hljs-tag">&lt;/<span class="hljs-name">title</span>&gt;</span>
  <span class="hljs-tag">&lt;<span class="hljs-name">link</span> /&gt;</span>
<span class="hljs-tag">&lt;/<span class="hljs-name">head</span>&gt;</span>
<span class="hljs-tag">&lt;<span class="hljs-name">body</span>&gt;</span>
  <span class="hljs-comment">&lt;!-- your web page content goes here --&gt;</span>
<span class="hljs-tag">&lt;/<span class="hljs-name">body</span>&gt;</span>
<span class="hljs-tag">&lt;/<span class="hljs-name">html</span>&gt;</span>
</code></pre>
<p>Let's break it down:</p>
<p><code>&lt;!DOCTYPE html&gt;</code>: defines the document type and version of HTML being used (HTML5 in this case).</p>
<p><code>&lt;html lang="en"&gt;</code> and <code>&lt;/html&gt;</code>: opening and closing tag of the root element that wraps the entire HTML content. The attribute <code>lang="en"</code> defines the language (in this case, USA English)</p>
<p><code>&lt;head&gt;</code> and <code>&lt;/head&gt;</code>: opening and closing tag of the <code>head</code> element contains meta-information <code>&lt;meta &gt;</code> about the HTML document, the page title <code>&lt;title&gt;&lt;/title&gt;</code> you see in the browser tab, and link <code>&lt;link /&gt;</code> which defines a link between your HTML document and an external resources, like stylesheet, favicon, import and so on.</p>
<p><code>&lt;body&gt;</code> and <code>&lt;/body&gt;</code> : opening and closing <code>body</code> tag encloses all the visible content of a web page, including text, images, links, forms, and other elements that users interact with.</p>
<p><strong>Note</strong>: All HTML elements have opening (<code>**&lt; &gt;**</code>) and closing (<code>**&lt;/ &gt;**</code>) tags, except for self-closing (<code>**&lt; &gt;**</code> or <code>**&lt; /&gt;**</code>) tags, which I will explain in more detail later.</p>
<h2 id="heading-comments">Comments</h2>
<p>Notice this <code>&lt;!-- your web page content goes here --&gt;</code> in the above html basic structure, it's called comments. Comments are used to add explanatory notes that are not displayed when the web page is viewed in a browser. They are useful for documenting your code, providing information to other developers, or temporarily excluding specific parts of the code. You can create comment using this tag <code>&lt;!--</code> <code>your comment goes here</code> <code>--&gt;</code>.</p>
<p>There are:</p>
<ol>
<li><p><strong>Single-line commen</strong>t: <code>&lt;!-- This is a single-line comment --&gt;</code></p>
</li>
<li><p><strong>Multi-line comment</strong>: <code>&lt;!-- This is a multi-line comment. It can span multiple lines. All content within the comment block will be ignored by the browser. --&gt;</code></p>
</li>
</ol>
<h2 id="heading-tags-and-elements">Tags and Elements</h2>
<p>HTML uses tags to define different elements on a webpage. Tags are enclosed in angle brackets (<code>&lt; &gt;</code>). There are opening (<code>&lt; &gt;</code>) and closing (<code>&lt;/ &gt;</code>) tags, and self-closing (<code>&lt; &gt;</code> or <code>&lt; /&gt;</code>) tag. Here are a few examples:</p>
<h3 id="heading-headings">Headings</h3>
<pre><code class="lang-html"><span class="hljs-tag">&lt;<span class="hljs-name">h1</span>&gt;</span>This is a Heading 1<span class="hljs-tag">&lt;/<span class="hljs-name">h1</span>&gt;</span>
<span class="hljs-tag">&lt;<span class="hljs-name">h2</span>&gt;</span>This is a Heading 2<span class="hljs-tag">&lt;/<span class="hljs-name">h2</span>&gt;</span>
<span class="hljs-comment">&lt;!-- ... up to &lt;h6&gt; --&gt;</span>
</code></pre>
<p>The heading tags <code>&lt;h1&gt;</code> to <code>&lt;h6&gt;</code> are used to define headings or subheadings within a document. These tags represent a hierarchy of headings, with <code>&lt;h1&gt;</code> being the highest level (main heading) and <code>&lt;h6&gt;</code> being the lowest level (lowest subheading level).</p>
<p>Its purpose is to structure and organize the content of a web page, making it more readable and accessible.</p>
<h3 id="heading-paragraph">Paragraph</h3>
<p>The paragraph tag (<code>&lt;p&gt; your text goes here &lt;/p&gt;</code>) is used to separate blocks of text into distinct paragraphs. It is a block-level element that represents a unit of text or a block of content, and it is commonly used to structure and separate text on a webpage.</p>
<p>The <code>&lt;p&gt;</code> tag is part of the structural markup in HTML and helps in creating well-organized and readable content.</p>
<h3 id="heading-line-breaks">Line Breaks</h3>
<p>To create a line break without starting a new paragraph, use the break (<code>&lt;br&gt;</code>) tag.</p>
<p>Example 1 - Basic Line Break:</p>
<pre><code class="lang-html"><span class="hljs-tag">&lt;<span class="hljs-name">p</span>&gt;</span>This is the first line.<span class="hljs-tag">&lt;<span class="hljs-name">br</span>&gt;</span>This is the second line.<span class="hljs-tag">&lt;/<span class="hljs-name">p</span>&gt;</span>
</code></pre>
<p>This will render as:</p>
<p>This is the first line.<br>This is the second line.</p>
<p>Example 2 - Line Breaks in Text:</p>
<pre><code class="lang-html"><span class="hljs-tag">&lt;<span class="hljs-name">p</span>&gt;</span>This text contains a<span class="hljs-tag">&lt;<span class="hljs-name">br</span>&gt;</span>line break.<span class="hljs-tag">&lt;/<span class="hljs-name">p</span>&gt;</span>
</code></pre>
<p>This will render as:</p>
<p>This text contains a<br>line break.</p>
<p>Example 3 - Line Breaks in List:</p>
<pre><code class="lang-html"><span class="hljs-tag">&lt;<span class="hljs-name">ul</span>&gt;</span>
  <span class="hljs-tag">&lt;<span class="hljs-name">li</span>&gt;</span>Item 1<span class="hljs-tag">&lt;/<span class="hljs-name">li</span>&gt;</span>
  <span class="hljs-tag">&lt;<span class="hljs-name">li</span>&gt;</span>Item 2<span class="hljs-tag">&lt;<span class="hljs-name">br</span>&gt;</span>with a line break<span class="hljs-tag">&lt;/<span class="hljs-name">li</span>&gt;</span>
  <span class="hljs-tag">&lt;<span class="hljs-name">li</span>&gt;</span>Item 3<span class="hljs-tag">&lt;/<span class="hljs-name">li</span>&gt;</span>
<span class="hljs-tag">&lt;/<span class="hljs-name">ul</span>&gt;</span>
</code></pre>
<p>This will render as:</p>
<ul>
<li><p>Item 1</p>
</li>
<li><p>Item 2<br>  with a line break</p>
</li>
<li><p>Item 3</p>
</li>
</ul>
<p>Example 4 - Line Breaks in Address:</p>
<pre><code class="lang-html"><span class="hljs-tag">&lt;<span class="hljs-name">address</span>&gt;</span>
  Nuel Cas<span class="hljs-tag">&lt;<span class="hljs-name">br</span>&gt;</span>
  23 Musa Yar'Dua VI<span class="hljs-tag">&lt;<span class="hljs-name">br</span>&gt;</span>
  Lagos, Nigeria
<span class="hljs-tag">&lt;/<span class="hljs-name">address</span>&gt;</span>
</code></pre>
<p>This will render as:</p>
<p>Nuel Cas<br>23 Musa Yar'Dua VI<br>Lagos, Nigeria</p>
<p>Example 5: Line Breaks with Multiple<br>Tags</p>
<pre><code class="lang-python">&lt;p&gt;This <span class="hljs-keyword">is</span> a paragraph <span class="hljs-keyword">with</span>&lt;br&gt;&lt;br&gt;multiple line breaks.&lt;/p&gt;
</code></pre>
<p>This will render as:</p>
<p>This is a paragraph with</p>
<p>multiple line breaks.</p>
<p>While break (<code>&lt;br&gt;</code>) tag is commonly used for simple line breaks, CSS and block-level elements like <code>&lt;p&gt;</code> and <code>&lt;div&gt;</code> tags are often preferred for more complex layouts.</p>
<p>Overusing <code>&lt;br&gt;</code> tags for layout purposes is discouraged. CSS is generally more suitable for controlling the spacing and layout of elements on a webpage.</p>
<h3 id="heading-div">Div</h3>
<p>A <code>&lt;div&gt;</code> tag, which stands for "division" is one of the most commonly used container elements in HTML. It is a block-level container that is used to group other HTML elements together and apply styles or scripting to them collectively.</p>
<p>Here's an example:</p>
<pre><code class="lang-html"><span class="hljs-tag">&lt;<span class="hljs-name">div</span>&gt;</span>
  <span class="hljs-tag">&lt;<span class="hljs-name">p</span>&gt;</span>This is a paragraph inside a div.<span class="hljs-tag">&lt;/<span class="hljs-name">p</span>&gt;</span>
  <span class="hljs-tag">&lt;<span class="hljs-name">ul</span>&gt;</span>
    <span class="hljs-tag">&lt;<span class="hljs-name">li</span>&gt;</span>List item 1<span class="hljs-tag">&lt;/<span class="hljs-name">li</span>&gt;</span>
    <span class="hljs-tag">&lt;<span class="hljs-name">li</span>&gt;</span>List item 2<span class="hljs-tag">&lt;/<span class="hljs-name">li</span>&gt;</span>
  <span class="hljs-tag">&lt;/<span class="hljs-name">ul</span>&gt;</span>
<span class="hljs-tag">&lt;/<span class="hljs-name">div</span>&gt;</span>
</code></pre>
<p>In this example, the <code>&lt;div&gt;</code> element wraps around a paragraph (<code>&lt;p&gt;</code>) and an unordered list (<code>&lt;ul&gt;</code>). This grouping allows you to apply styles or manipulate these elements together using CSS or JavaScript.</p>
<p><strong>Note</strong>: The <code>&lt;div&gt;</code> tag is often used for layout purposes, helping structure the content of a webpage. For more semantic and specific meanings, HTML5 introduced new semantic tags like <code>&lt;section&gt;</code>, <code>&lt;article&gt;</code>, <code>&lt;header&gt;</code>, <code>&lt;footer&gt;</code>, and so on, which provide better clarity about the content's purpose.</p>
<h3 id="heading-semantic-tags">Semantic Tags</h3>
<p>They are like special labels that tell web browsers and developers what different parts of a webpage are all about. They help make websites easier to understand for both people and computers.</p>
<p>By using these tags, you can make your websites more accessible and easier to find on search engines. Here are some common HTML semantic tags along with examples:</p>
<ol>
<li><code>&lt;header&gt;</code>: The header tag represents introductory content at the beginning of a section or webpage. It typically contains logos, navigation menus, and other introductory elements.</li>
</ol>
<p>Example:</p>
<pre><code class="lang-html">  <span class="hljs-tag">&lt;<span class="hljs-name">header</span>&gt;</span>
  <span class="hljs-tag">&lt;<span class="hljs-name">h1</span>&gt;</span>Website Title<span class="hljs-tag">&lt;/<span class="hljs-name">h1</span>&gt;</span>
  <span class="hljs-tag">&lt;<span class="hljs-name">nav</span>&gt;</span>
    <span class="hljs-tag">&lt;<span class="hljs-name">ul</span>&gt;</span>
      <span class="hljs-tag">&lt;<span class="hljs-name">li</span>&gt;</span><span class="hljs-tag">&lt;<span class="hljs-name">a</span> <span class="hljs-attr">href</span>=<span class="hljs-string">"#"</span>&gt;</span>Home<span class="hljs-tag">&lt;/<span class="hljs-name">a</span>&gt;</span><span class="hljs-tag">&lt;/<span class="hljs-name">li</span>&gt;</span>
      <span class="hljs-tag">&lt;<span class="hljs-name">li</span>&gt;</span><span class="hljs-tag">&lt;<span class="hljs-name">a</span> <span class="hljs-attr">href</span>=<span class="hljs-string">"#"</span>&gt;</span>About<span class="hljs-tag">&lt;/<span class="hljs-name">a</span>&gt;</span><span class="hljs-tag">&lt;/<span class="hljs-name">li</span>&gt;</span>
      <span class="hljs-tag">&lt;<span class="hljs-name">li</span>&gt;</span><span class="hljs-tag">&lt;<span class="hljs-name">a</span> <span class="hljs-attr">href</span>=<span class="hljs-string">"#"</span>&gt;</span>Contact<span class="hljs-tag">&lt;/<span class="hljs-name">a</span>&gt;</span><span class="hljs-tag">&lt;/<span class="hljs-name">li</span>&gt;</span>
    <span class="hljs-tag">&lt;/<span class="hljs-name">ul</span>&gt;</span>
  <span class="hljs-tag">&lt;/<span class="hljs-name">nav</span>&gt;</span>
<span class="hljs-tag">&lt;/<span class="hljs-name">header</span>&gt;</span>
</code></pre>
<ol start="2">
<li><code>&lt;nav&gt;</code>: Use nav tag to define navigation links within your webpage. It contains links to other pages or sections of the website.</li>
</ol>
<p>Example:</p>
<pre><code class="lang-html"><span class="hljs-tag">&lt;<span class="hljs-name">nav</span>&gt;</span>
  <span class="hljs-tag">&lt;<span class="hljs-name">ul</span>&gt;</span>
    <span class="hljs-tag">&lt;<span class="hljs-name">li</span>&gt;</span><span class="hljs-tag">&lt;<span class="hljs-name">a</span> <span class="hljs-attr">href</span>=<span class="hljs-string">"#"</span>&gt;</span>Home<span class="hljs-tag">&lt;/<span class="hljs-name">a</span>&gt;</span><span class="hljs-tag">&lt;/<span class="hljs-name">li</span>&gt;</span>
    <span class="hljs-tag">&lt;<span class="hljs-name">li</span>&gt;</span><span class="hljs-tag">&lt;<span class="hljs-name">a</span> <span class="hljs-attr">href</span>=<span class="hljs-string">"#"</span>&gt;</span>About<span class="hljs-tag">&lt;/<span class="hljs-name">a</span>&gt;</span><span class="hljs-tag">&lt;/<span class="hljs-name">li</span>&gt;</span>
    <span class="hljs-tag">&lt;<span class="hljs-name">li</span>&gt;</span><span class="hljs-tag">&lt;<span class="hljs-name">a</span> <span class="hljs-attr">href</span>=<span class="hljs-string">"#"</span>&gt;</span>Contact<span class="hljs-tag">&lt;/<span class="hljs-name">a</span>&gt;</span><span class="hljs-tag">&lt;/<span class="hljs-name">li</span>&gt;</span>
  <span class="hljs-tag">&lt;/<span class="hljs-name">ul</span>&gt;</span>
<span class="hljs-tag">&lt;/<span class="hljs-name">nav</span>&gt;</span>
</code></pre>
<ol start="3">
<li><code>&lt;main&gt;</code>: Used to define the main content of a webpage. It helps improve the accessibility and structure of your HTML code, as it clearly identifies the main content area for screen readers and other assistive technologies. It also helps search engines understand the relevance of the content on your page, which can improve your website's Search Engine Optimization (SEO).</li>
</ol>
<p>Example:</p>
<pre><code class="lang-html"><span class="hljs-tag">&lt;<span class="hljs-name">main</span>&gt;</span>
  <span class="hljs-tag">&lt;<span class="hljs-name">article</span>&gt;</span>
    <span class="hljs-tag">&lt;<span class="hljs-name">h2</span>&gt;</span>Page Title<span class="hljs-tag">&lt;/<span class="hljs-name">h2</span>&gt;</span>
    <span class="hljs-tag">&lt;<span class="hljs-name">p</span>&gt;</span>Page content goes here...<span class="hljs-tag">&lt;/<span class="hljs-name">p</span>&gt;</span>
  <span class="hljs-tag">&lt;/<span class="hljs-name">article</span>&gt;</span>
<span class="hljs-tag">&lt;/<span class="hljs-name">main</span>&gt;</span>
</code></pre>
<ol start="4">
<li><code>&lt;section&gt;</code>: Use the <code>section</code> tag when you want to define sections within a webpage. Also, for grouping related content together.</li>
</ol>
<p>Example:</p>
<pre><code class="lang-html"><span class="hljs-tag">&lt;<span class="hljs-name">section</span>&gt;</span>
  <span class="hljs-tag">&lt;<span class="hljs-name">h2</span>&gt;</span>Section Title<span class="hljs-tag">&lt;/<span class="hljs-name">h2</span>&gt;</span>
  <span class="hljs-tag">&lt;<span class="hljs-name">p</span>&gt;</span>Section content goes here...<span class="hljs-tag">&lt;/<span class="hljs-name">p</span>&gt;</span>
<span class="hljs-tag">&lt;/<span class="hljs-name">section</span>&gt;</span>
</code></pre>
<ol start="5">
<li><code>&lt;article&gt;</code>: Use the <code>article</code> tag when you want to define an independent piece of content that can stand alone, such as a blog post, news article, or forum post.</li>
</ol>
<p>Example:</p>
<pre><code class="lang-html"><span class="hljs-tag">&lt;<span class="hljs-name">article</span>&gt;</span>
  <span class="hljs-tag">&lt;<span class="hljs-name">h2</span>&gt;</span>Article Title<span class="hljs-tag">&lt;/<span class="hljs-name">h2</span>&gt;</span>
  <span class="hljs-tag">&lt;<span class="hljs-name">p</span>&gt;</span>Article content goes here...<span class="hljs-tag">&lt;/<span class="hljs-name">p</span>&gt;</span>
<span class="hljs-tag">&lt;/<span class="hljs-name">article</span>&gt;</span>
</code></pre>
<ol start="6">
<li><code>&lt;aside&gt;</code>: Use the <code>aside</code> tag when you want to define content that is related to the main content but not part of it, such as sidebars, advertisements, or related links.</li>
</ol>
<p>Example:</p>
<pre><code class="lang-html"><span class="hljs-tag">&lt;<span class="hljs-name">aside</span>&gt;</span>
  <span class="hljs-tag">&lt;<span class="hljs-name">h3</span>&gt;</span>Related Links<span class="hljs-tag">&lt;/<span class="hljs-name">h3</span>&gt;</span>
  <span class="hljs-tag">&lt;<span class="hljs-name">ul</span>&gt;</span>
    <span class="hljs-tag">&lt;<span class="hljs-name">li</span>&gt;</span><span class="hljs-tag">&lt;<span class="hljs-name">a</span> <span class="hljs-attr">href</span>=<span class="hljs-string">"#"</span>&gt;</span>Link 1<span class="hljs-tag">&lt;/<span class="hljs-name">a</span>&gt;</span><span class="hljs-tag">&lt;/<span class="hljs-name">li</span>&gt;</span>
    <span class="hljs-tag">&lt;<span class="hljs-name">li</span>&gt;</span><span class="hljs-tag">&lt;<span class="hljs-name">a</span> <span class="hljs-attr">href</span>=<span class="hljs-string">"#"</span>&gt;</span>Link 2<span class="hljs-tag">&lt;/<span class="hljs-name">a</span>&gt;</span><span class="hljs-tag">&lt;/<span class="hljs-name">li</span>&gt;</span>
    <span class="hljs-tag">&lt;<span class="hljs-name">li</span>&gt;</span><span class="hljs-tag">&lt;<span class="hljs-name">a</span> <span class="hljs-attr">href</span>=<span class="hljs-string">"#"</span>&gt;</span>Link 3<span class="hljs-tag">&lt;/<span class="hljs-name">a</span>&gt;</span><span class="hljs-tag">&lt;/<span class="hljs-name">li</span>&gt;</span>
  <span class="hljs-tag">&lt;/<span class="hljs-name">ul</span>&gt;</span>
<span class="hljs-tag">&lt;/<span class="hljs-name">aside</span>&gt;</span>
</code></pre>
<ol start="7">
<li><code>&lt;footer&gt;</code>: Used to define the footer of a webpage, typically containing copyright information, contact details, or links to related pages.</li>
</ol>
<p>Example:</p>
<pre><code class="lang-html"><span class="hljs-tag">&lt;<span class="hljs-name">footer</span>&gt;</span>
  <span class="hljs-tag">&lt;<span class="hljs-name">p</span>&gt;</span><span class="hljs-symbol">&amp;copy;</span> Nuel Cas Website<span class="hljs-tag">&lt;/<span class="hljs-name">p</span>&gt;</span>
<span class="hljs-tag">&lt;/<span class="hljs-name">footer</span>&gt;</span>
</code></pre>
<h3 id="heading-list-tag">List Tag</h3>
<p>Lists <code>&lt;li&gt;</code> allow you to organize and structure content in a hierarchical manner. They are two types: ordered <code>&lt;ol&gt;</code> (numbered) and unordered (<code>&lt;ul&gt;</code>) (bulleted) lists.</p>
<p>Ordered List: Use <code>&lt;ol&gt;</code> for ordered lists, and <code>&lt;li&gt;</code> for list items.</p>
<p>Example:</p>
<pre><code class="lang-html"><span class="hljs-tag">&lt;<span class="hljs-name">ol</span>&gt;</span>
  <span class="hljs-tag">&lt;<span class="hljs-name">li</span>&gt;</span>First item<span class="hljs-tag">&lt;/<span class="hljs-name">li</span>&gt;</span>
  <span class="hljs-tag">&lt;<span class="hljs-name">li</span>&gt;</span>Second item<span class="hljs-tag">&lt;/<span class="hljs-name">li</span>&gt;</span>
  <span class="hljs-tag">&lt;<span class="hljs-name">li</span>&gt;</span>Third item<span class="hljs-tag">&lt;/<span class="hljs-name">li</span>&gt;</span>
<span class="hljs-tag">&lt;/<span class="hljs-name">ol</span>&gt;</span>
</code></pre>
<p>This will render as:</p>
<ol>
<li><p>First item</p>
</li>
<li><p>Second item</p>
</li>
<li><p>Third item</p>
</li>
</ol>
<p>Unordered List: The <code>&lt;ul&gt;</code> tag is used to create an unordered list, where the order of the items doesn't matter, it renders bulleted items. Each item in the list is represented by the <code>&lt;li&gt;</code> (list item) tag.</p>
<p>Example:</p>
<pre><code class="lang-html"><span class="hljs-tag">&lt;<span class="hljs-name">ul</span>&gt;</span>
  <span class="hljs-tag">&lt;<span class="hljs-name">li</span>&gt;</span>Item 1<span class="hljs-tag">&lt;/<span class="hljs-name">li</span>&gt;</span>
  <span class="hljs-tag">&lt;<span class="hljs-name">li</span>&gt;</span>Item 2<span class="hljs-tag">&lt;/<span class="hljs-name">li</span>&gt;</span>
  <span class="hljs-tag">&lt;<span class="hljs-name">li</span>&gt;</span>Item 3<span class="hljs-tag">&lt;/<span class="hljs-name">li</span>&gt;</span>
<span class="hljs-tag">&lt;/<span class="hljs-name">ul</span>&gt;</span>
</code></pre>
<p>This will render as:</p>
<ul>
<li><p>Item 1</p>
</li>
<li><p>Item 2</p>
</li>
<li><p>Item 3</p>
</li>
</ul>
<p>Lists can be nested within each other. For example, you can have an ordered list within an unordered list or vice versa.</p>
<p>Example:</p>
<pre><code class="lang-html"><span class="hljs-tag">&lt;<span class="hljs-name">ul</span>&gt;</span>
  <span class="hljs-tag">&lt;<span class="hljs-name">li</span>&gt;</span>Unordered List Item 1<span class="hljs-tag">&lt;/<span class="hljs-name">li</span>&gt;</span>
  <span class="hljs-tag">&lt;<span class="hljs-name">li</span>&gt;</span>Unordered List Item 2
    <span class="hljs-tag">&lt;<span class="hljs-name">ol</span>&gt;</span>
      <span class="hljs-tag">&lt;<span class="hljs-name">li</span>&gt;</span>Ordered List Item 1<span class="hljs-tag">&lt;/<span class="hljs-name">li</span>&gt;</span>
      <span class="hljs-tag">&lt;<span class="hljs-name">li</span>&gt;</span>Ordered List Item 2<span class="hljs-tag">&lt;/<span class="hljs-name">li</span>&gt;</span>
    <span class="hljs-tag">&lt;/<span class="hljs-name">ol</span>&gt;</span>
  <span class="hljs-tag">&lt;/<span class="hljs-name">li</span>&gt;</span>
  <span class="hljs-tag">&lt;<span class="hljs-name">li</span>&gt;</span>Unordered List Item 3<span class="hljs-tag">&lt;/<span class="hljs-name">li</span>&gt;</span>
<span class="hljs-tag">&lt;/<span class="hljs-name">ul</span>&gt;</span>
</code></pre>
<p>This will render as:</p>
<ul>
<li><p>Unordered List Item 1</p>
</li>
<li><p>Unordered List Item 2</p>
</li>
</ul>
<ol>
<li><p>Ordered List Item 1</p>
</li>
<li><p>Ordered List Item 2</p>
</li>
</ol>
<ul>
<li>Unordered List Item 3</li>
</ul>
<p>List items can also have attributes. For example, you might use the <code>type</code> attribute with the <code>&lt;ol&gt;</code> tag to change the numbering style.</p>
<p>Example:</p>
<pre><code class="lang-html"><span class="hljs-tag">&lt;<span class="hljs-name">ol</span> <span class="hljs-attr">type</span>=<span class="hljs-string">"A"</span>&gt;</span>
  <span class="hljs-tag">&lt;<span class="hljs-name">li</span>&gt;</span>Item 1<span class="hljs-tag">&lt;/<span class="hljs-name">li</span>&gt;</span>
  <span class="hljs-tag">&lt;<span class="hljs-name">li</span>&gt;</span>Item 2<span class="hljs-tag">&lt;/<span class="hljs-name">li</span>&gt;</span>
  <span class="hljs-tag">&lt;<span class="hljs-name">li</span>&gt;</span>Item 3<span class="hljs-tag">&lt;/<span class="hljs-name">li</span>&gt;</span>
<span class="hljs-tag">&lt;/<span class="hljs-name">ol</span>&gt;</span>
</code></pre>
<p>This will render as:</p>
<p>A. Item 1<br>B. Item 2<br>C. Item 3</p>
<p>The <code>&lt;ul&gt;</code>, <code>&lt;ol&gt;</code>, and <code>&lt;li&gt;</code> tags in HTML are essential for creating organized lists and structuring content on web pages. They provide flexibility in presenting information in both ordered and unordered formats.</p>
<h3 id="heading-span-tag">Span Tag</h3>
<p>The <code>&lt;span&gt;</code> tag is a generic inline (it does not create a line break) container used to group and apply styles to inline elements or text. It is typically used when you want to apply styles or using JavaScript to manipulate specific portions of text within a larger block of content without affecting the overall structure.</p>
<p>Here's an example of how the <code>&lt;span&gt;</code> tag can be used in HTML:</p>
<pre><code class="lang-html"><span class="hljs-tag">&lt;<span class="hljs-name">p</span>&gt;</span>This is a <span class="hljs-tag">&lt;<span class="hljs-name">span</span> <span class="hljs-attr">style</span>=<span class="hljs-string">"color: red; font-weight: bold;"</span>&gt;</span>highlighted<span class="hljs-tag">&lt;/<span class="hljs-name">span</span>&gt;</span> text.<span class="hljs-tag">&lt;/<span class="hljs-name">p</span>&gt;</span>
</code></pre>
<p>In this example, the word "highlighted" will be displayed in red and bold, as specified by the inline styles applied to the <code>&lt;span&gt;</code> element.</p>
<h3 id="heading-links">Links</h3>
<p>The <code>&lt;link&gt;</code> tag is used to define a link between a document and an external resource. Its primary purpose is to include external resources, such as stylesheets, icons, and other documents. Let's look at the common use cases of the <code>&lt;link&gt;</code> tag:</p>
<p><strong>Linking stylesheet</strong>: The most common use of the <code>&lt;link&gt;</code> tag is to link an external CSS (Cascading Style Sheets) file to an HTML document. This allows you to separate the styling of your website from its structure, making it easier to maintain and update.</p>
<p>Example:</p>
<pre><code class="lang-html"><span class="hljs-tag">&lt;<span class="hljs-name">link</span> <span class="hljs-attr">rel</span>=<span class="hljs-string">"stylesheet"</span> <span class="hljs-attr">type</span>=<span class="hljs-string">"text/css"</span> <span class="hljs-attr">href</span>=<span class="hljs-string">"styles.css"</span>&gt;</span>
</code></pre>
<p>In this example, the <code>rel</code> attribute specifies the relationship between the HTML document and the linked resource (stylesheet), the <code>type</code> attribute indicates the type of the linked resource (<code>text/css</code> for stylesheets), and the <code>href</code> attribute specifies the path to the external CSS file.</p>
<p><strong>Note</strong>: Linking a CSS file should be done inside the <code>&lt;head&gt;</code> element.</p>
<p><strong>Linking icon</strong>: The <code>&lt;link&gt;</code> tag is also commonly used to link the favicon icon for a webpage, which is the small icon that appears in the browser tab or next to the URL in the address bar.</p>
<pre><code class="lang-html"><span class="hljs-tag">&lt;<span class="hljs-name">link</span> <span class="hljs-attr">rel</span>=<span class="hljs-string">"icon"</span> <span class="hljs-attr">href</span>=<span class="hljs-string">"favicon.ico"</span> <span class="hljs-attr">type</span>=<span class="hljs-string">"image/x-icon"</span>&gt;</span>
</code></pre>
<p>In this case, the <code>rel</code> attribute is set to "icon" to indicate that it is an icon file, and the <code>href</code> attribute specifies the path to the icon file. The <code>type</code> attribute indicates the type of the linked file, in this case, <code>image/x-icon</code> for icons.</p>
<p><strong>Linking external documents</strong>: The <code>&lt;link&gt;</code> tag can be used to link other external documents, such as:</p>
<ol>
<li>Stylesheet for printing: Imagine you have a special design for when someone wants to print your webpage. The <code>&lt;link&gt;</code> tag can connect your webpage to a separate stylesheet designed just for printing. This way, when someone prints your page, it looks nice and tidy.</li>
</ol>
<p>Example:</p>
<pre><code class="lang-html"><span class="hljs-comment">&lt;!-- Link to the stylesheet for printing --&gt;</span>
  <span class="hljs-tag">&lt;<span class="hljs-name">link</span> <span class="hljs-attr">rel</span>=<span class="hljs-string">"stylesheet"</span> <span class="hljs-attr">type</span>=<span class="hljs-string">"text/css"</span> <span class="hljs-attr">href</span>=<span class="hljs-string">"print-styles.css"</span> <span class="hljs-attr">media</span>=<span class="hljs-string">"print"</span>&gt;</span>
</code></pre>
<ol start="2">
<li>Alternative versions of a document (like translations): Sometimes, you might have different versions of your webpage for different languages or purposes. The <code>&lt;link&gt;</code> tag can connect your webpage to these alternative versions.</li>
</ol>
<p>Example:</p>
<pre><code class="lang-html"><span class="hljs-tag">&lt;<span class="hljs-name">link</span> <span class="hljs-attr">rel</span>=<span class="hljs-string">"alternate"</span> <span class="hljs-attr">hreflang</span>=<span class="hljs-string">"es"</span> <span class="hljs-attr">href</span>=<span class="hljs-string">"spanish-version.html"</span>&gt;</span>
</code></pre>
<ol start="3">
<li>Feeds for content syndication: Let's say you have a blog, and you want others to easily see your latest posts. The <code>&lt;link&gt;</code> tag can help by connecting your webpage to a feed, which is like a stream of your latest content.</li>
</ol>
<p>Example:</p>
<pre><code class="lang-html"><span class="hljs-tag">&lt;<span class="hljs-name">link</span> <span class="hljs-attr">rel</span>=<span class="hljs-string">"alternate"</span> <span class="hljs-attr">type</span>=<span class="hljs-string">"application/rss+xml"</span> <span class="hljs-attr">title</span>=<span class="hljs-string">"RSS Feed"</span> <span class="hljs-attr">href</span>=<span class="hljs-string">"rss-feed.xml"</span>&gt;</span>
</code></pre>
<p>The <code>&lt;link&gt;</code> tag is like a connector that helps your webpage interact with other files on the internet.</p>
<h3 id="heading-anchor-tag">Anchor Tag</h3>
<p>The anchor tag, represented by <code>&lt;a&gt;</code>, is used to create hyperlinks or anchor points within a webpage. It is primarily used to define a hyperlink, allowing users to navigate to another webpage, a different section of the same page, or even an external resource.</p>
<p>The anchor tag uses the <code>href</code> attribute to specify the destination URL (Uniform Resource Locator).</p>
<p>Example:</p>
<pre><code class="lang-html"><span class="hljs-tag">&lt;<span class="hljs-name">a</span> <span class="hljs-attr">href</span>=<span class="hljs-string">"https://www.example.com"</span>&gt;</span>Visit Example.com<span class="hljs-tag">&lt;/<span class="hljs-name">a</span>&gt;</span>
</code></pre>
<h3 id="heading-form-tag">Form tag</h3>
<p>HTML forms are essential for user interaction on websites. They allow users to input data that can be sent to a server for processing. The basic structure of an HTML form involves several key elements:</p>
<pre><code class="lang-html"><span class="hljs-tag">&lt;<span class="hljs-name">form</span>&gt;</span>
  <span class="hljs-comment">&lt;!-- Your form elements go here --&gt;</span>
<span class="hljs-tag">&lt;/<span class="hljs-name">form</span>&gt;</span>
</code></pre>
<p>The <code>&lt;form&gt;</code> tag marks the beginning and end of your form. It acts as a container for various form elements. It commonly houses label, input types, textarea, and button tags.</p>
<h4 id="heading-label">Label</h4>
<p>The <code>&lt;label&gt;</code> tag is used to define a label for an input element. Example:</p>
<pre><code class="lang-html"><span class="hljs-tag">&lt;<span class="hljs-name">label</span> <span class="hljs-attr">for</span>=<span class="hljs-string">"username"</span>&gt;</span>Username:<span class="hljs-tag">&lt;/<span class="hljs-name">label</span>&gt;</span>
</code></pre>
<h4 id="heading-input-type">Input type</h4>
<p>In a form, different input types serve various purposes. The input (<code>&lt;input&gt;</code>) tag defines an interactive element for users to enter data. Commonly used ones are:</p>
<p>Text Input:</p>
<pre><code class="lang-html"><span class="hljs-tag">&lt;<span class="hljs-name">input</span> <span class="hljs-attr">type</span>=<span class="hljs-string">"text"</span> <span class="hljs-attr">name</span>=<span class="hljs-string">"username"</span> <span class="hljs-attr">placeholder</span>=<span class="hljs-string">"Enter your username"</span>&gt;</span>
</code></pre>
<p>Password Input:</p>
<pre><code class="lang-html"><span class="hljs-tag">&lt;<span class="hljs-name">input</span> <span class="hljs-attr">type</span>=<span class="hljs-string">"password"</span> <span class="hljs-attr">name</span>=<span class="hljs-string">"password"</span> <span class="hljs-attr">placeholder</span>=<span class="hljs-string">"Enter your password"</span>&gt;</span>
</code></pre>
<p>Radio Buttons:</p>
<pre><code class="lang-html"><span class="hljs-tag">&lt;<span class="hljs-name">input</span> <span class="hljs-attr">type</span>=<span class="hljs-string">"radio"</span> <span class="hljs-attr">name</span>=<span class="hljs-string">"gender"</span> <span class="hljs-attr">value</span>=<span class="hljs-string">"male"</span>&gt;</span> Male
<span class="hljs-tag">&lt;<span class="hljs-name">input</span> <span class="hljs-attr">type</span>=<span class="hljs-string">"radio"</span> <span class="hljs-attr">name</span>=<span class="hljs-string">"gender"</span> <span class="hljs-attr">value</span>=<span class="hljs-string">"female"</span>&gt;</span> Female
</code></pre>
<p>Checkboxes:</p>
<pre><code class="lang-html"><span class="hljs-tag">&lt;<span class="hljs-name">input</span> <span class="hljs-attr">type</span>=<span class="hljs-string">"checkbox"</span> <span class="hljs-attr">name</span>=<span class="hljs-string">"subscribe"</span> <span class="hljs-attr">value</span>=<span class="hljs-string">"yes"</span>&gt;</span> Subscribe to newsletter
</code></pre>
<h4 id="heading-textarea">Textarea</h4>
<p>The <code>&lt;textarea&gt;</code> tag defines a multi-line text input control, commonly used within form elements. Example:</p>
<pre><code class="lang-python">&lt;textarea name=<span class="hljs-string">"message"</span> placeholder=<span class="hljs-string">"Enter your message"</span>&gt;&lt;/textarea&gt;
</code></pre>
<h4 id="heading-button-for-submitting-forms">Button (for submitting forms)</h4>
<p>The most crucial part of a form is allowing users to submit their input. For this, you can use a button (<code>&lt;button&gt;</code>) tag to submit:</p>
<p>Example:</p>
<pre><code class="lang-python">&lt;button type=<span class="hljs-string">"submit"</span>&gt;Submit&lt;/button&gt;
</code></pre>
<p>The <code>&lt;button&gt;</code> tag creates a clickable button. The <code>type="submit"</code> attribute indicates that clicking this button will submit the form.</p>
<h3 id="heading-quick-tips">Quick Tips</h3>
<ul>
<li><p>Always include a <code>name</code> attribute in your form elements. It helps identify and process the data on the server.</p>
</li>
<li><p>Use the <code>placeholder</code> attribute to give users a hint about the expected input.</p>
</li>
<li><p>Consider the user experience when choosing input types. For instance, use radio buttons for mutually exclusive options.</p>
</li>
</ul>
<p>Here is a code snippet demonstrating usage of a form element:</p>
<pre><code class="lang-html"><span class="hljs-tag">&lt;<span class="hljs-name">form</span>&gt;</span>
  <span class="hljs-tag">&lt;<span class="hljs-name">label</span> <span class="hljs-attr">for</span>=<span class="hljs-string">"username"</span>&gt;</span>Username:<span class="hljs-tag">&lt;/<span class="hljs-name">label</span>&gt;</span>
  <span class="hljs-tag">&lt;<span class="hljs-name">input</span> <span class="hljs-attr">type</span>=<span class="hljs-string">"text"</span> <span class="hljs-attr">id</span>=<span class="hljs-string">"username"</span> <span class="hljs-attr">name</span>=<span class="hljs-string">"username"</span> <span class="hljs-attr">placeholder</span>=<span class="hljs-string">"Enter your username"</span>&gt;</span>

  <span class="hljs-tag">&lt;<span class="hljs-name">label</span> <span class="hljs-attr">for</span>=<span class="hljs-string">"password"</span>&gt;</span>Password:<span class="hljs-tag">&lt;/<span class="hljs-name">label</span>&gt;</span>
  <span class="hljs-tag">&lt;<span class="hljs-name">input</span> <span class="hljs-attr">type</span>=<span class="hljs-string">"password"</span> <span class="hljs-attr">id</span>=<span class="hljs-string">"password"</span> <span class="hljs-attr">name</span>=<span class="hljs-string">"password"</span> <span class="hljs-attr">placeholder</span>=<span class="hljs-string">"Enter your password"</span>&gt;</span>

  <span class="hljs-tag">&lt;<span class="hljs-name">label</span>&gt;</span>Gender:<span class="hljs-tag">&lt;/<span class="hljs-name">label</span>&gt;</span>
  <span class="hljs-tag">&lt;<span class="hljs-name">input</span> <span class="hljs-attr">type</span>=<span class="hljs-string">"radio"</span> <span class="hljs-attr">name</span>=<span class="hljs-string">"gender"</span> <span class="hljs-attr">value</span>=<span class="hljs-string">"male"</span>&gt;</span> Male
  <span class="hljs-tag">&lt;<span class="hljs-name">input</span> <span class="hljs-attr">type</span>=<span class="hljs-string">"radio"</span> <span class="hljs-attr">name</span>=<span class="hljs-string">"gender"</span> <span class="hljs-attr">value</span>=<span class="hljs-string">"female"</span>&gt;</span> Female

  <span class="hljs-tag">&lt;<span class="hljs-name">label</span>&gt;</span>Subscribe to newsletter:<span class="hljs-tag">&lt;/<span class="hljs-name">label</span>&gt;</span>
  <span class="hljs-tag">&lt;<span class="hljs-name">input</span> <span class="hljs-attr">type</span>=<span class="hljs-string">"checkbox"</span> <span class="hljs-attr">name</span>=<span class="hljs-string">"subscribe"</span> <span class="hljs-attr">value</span>=<span class="hljs-string">"yes"</span>&gt;</span>

  <span class="hljs-tag">&lt;<span class="hljs-name">label</span> <span class="hljs-attr">for</span>=<span class="hljs-string">"message"</span>&gt;</span>Your Message:<span class="hljs-tag">&lt;/<span class="hljs-name">label</span>&gt;</span>
  <span class="hljs-tag">&lt;<span class="hljs-name">textarea</span> <span class="hljs-attr">id</span>=<span class="hljs-string">"message"</span> <span class="hljs-attr">name</span>=<span class="hljs-string">"message"</span> <span class="hljs-attr">placeholder</span>=<span class="hljs-string">"Enter your message"</span>&gt;</span><span class="hljs-tag">&lt;/<span class="hljs-name">textarea</span>&gt;</span>

  <span class="hljs-tag">&lt;<span class="hljs-name">button</span> <span class="hljs-attr">type</span>=<span class="hljs-string">"submit"</span>&gt;</span>Submit<span class="hljs-tag">&lt;/<span class="hljs-name">button</span>&gt;</span>
<span class="hljs-tag">&lt;/<span class="hljs-name">form</span>&gt;</span>
</code></pre>
<h3 id="heading-self-closing-tags">Self-closing Tags</h3>
<p>The <code>&lt;input&gt;</code> or <code>&lt;input /&gt;</code> element above is a self-closing tag, which means it doesn't require a separate closing tag.</p>
<p>There are other self-closing tags in HTML:</p>
<ul>
<li><p>Image (<code>&lt;img&gt;</code> or <code>&lt;img /&gt;</code>).</p>
</li>
<li><p>Line breaks (<code>&lt;br&gt;</code> or <code>&lt;br /&gt;</code>).</p>
</li>
<li><p>External resource link (<code>&lt;link&gt;</code> or <code>&lt;link /&gt;</code>).</p>
</li>
<li><p>Horizontal rule (<code>&lt;hr&gt;</code> or <code>&lt;hr /&gt;</code>).</p>
</li>
<li><p>Meta data (<code>&lt;meta&gt;</code> or <code>&lt;meta /&gt;</code>).</p>
</li>
<li><p>Table column (<code>&lt;col&gt;</code> or <code>&lt;col /&gt;</code>).</p>
</li>
<li><p>Base URL for relative links (<code>&lt;base&gt;</code> or <code>&lt;base /&gt;</code>).</p>
</li>
<li><p>Word break opportunity (<code>&lt;wbr&gt;</code> or <code>&lt;wbr /&gt;</code>).</p>
</li>
<li><p>Area (<code>&lt;area&gt;</code> or <code>&lt;area /&gt;</code>) which defines an area inside an image map so the image can have a clickable region.</p>
</li>
</ul>
<p>Note: HTML5 (latest version of HTML) allows you to omit the slash (<code>/</code>) at the end of self-closing tags, but including it ensures compatibility with older standards like XHTML and some tools.</p>
<h2 id="heading-html-attributes">HTML Attributes</h2>
<p>This is an additional information or characteristics that you can apply to HTML elements to modify their behavior, appearance, or define certain properties. Attributes are always included in the opening tag of an HTML element and are written as name-value pairs.</p>
<p>The basic syntax for an HTML attribute is:</p>
<pre><code class="lang-html"><span class="hljs-tag">&lt;<span class="hljs-name">tagname</span> <span class="hljs-attr">attribute</span>=<span class="hljs-string">"value"</span>&gt;</span>Content<span class="hljs-tag">&lt;/<span class="hljs-name">tagname</span>&gt;</span>
</code></pre>
<p>Here, <code>attribute</code> is the name of the attribute, and <code>"value"</code> is the value assigned to that attribute.</p>
<p>There are many attributes available for various HTML elements, here are few ones:</p>
<h3 id="heading-id-attribute">id Attribute</h3>
<p>It provides a unique identifier for an HTML element. It should be unique within the entire HTML document.</p>
<p>"id" attribute helps you uniquely identify and control specific elements on a webpage, just like how each student's ID number helps identify them uniquely in a school.</p>
<p>Example:</p>
<pre><code class="lang-html"><span class="hljs-tag">&lt;<span class="hljs-name">div</span> <span class="hljs-attr">id</span>=<span class="hljs-string">"header"</span>&gt;</span>This is a div with an id attribute.<span class="hljs-tag">&lt;/<span class="hljs-name">div</span>&gt;</span>
</code></pre>
<h3 id="heading-class-attribute">class Attribute</h3>
<p>Used to assign one or more class names to an HTML element. It also helps you organize and style different parts of a webpage by grouping them together.</p>
<p>Here is the syntax for class attribute:</p>
<pre><code class="lang-html"><span class="hljs-tag">&lt;<span class="hljs-name">tagname</span> <span class="hljs-attr">class</span>=<span class="hljs-string">"classname1 classname2 ..."</span>&gt;</span>Content<span class="hljs-tag">&lt;/<span class="hljs-name">tagname</span>&gt;</span>
</code></pre>
<p>Suppose you want to style multiple paragraphs with the same font and color. Instead of writing the same CSS styles for each paragraph individually, you can assign a common class to all those paragraphs and define the styles for that class in your CSS file. Example:</p>
<pre><code class="lang-html"><span class="hljs-tag">&lt;<span class="hljs-name">body</span>&gt;</span>
  <span class="hljs-tag">&lt;<span class="hljs-name">p</span> <span class="hljs-attr">class</span>=<span class="hljs-string">"highlight"</span>&gt;</span>This is the first paragraph.<span class="hljs-tag">&lt;/<span class="hljs-name">p</span>&gt;</span>
  <span class="hljs-tag">&lt;<span class="hljs-name">p</span> <span class="hljs-attr">class</span>=<span class="hljs-string">"highlight"</span>&gt;</span>This is the second paragraph.<span class="hljs-tag">&lt;/<span class="hljs-name">p</span>&gt;</span>
  <span class="hljs-tag">&lt;<span class="hljs-name">p</span> <span class="hljs-attr">class</span>=<span class="hljs-string">"highlight"</span>&gt;</span>This is the third paragraph.<span class="hljs-tag">&lt;/<span class="hljs-name">p</span>&gt;</span>
<span class="hljs-tag">&lt;/<span class="hljs-name">body</span>&gt;</span>
</code></pre>
<p><strong>Note</strong>: The "id" attribute and the "class" attribute in HTML serve similar purposes in that they both allow you to uniquely identify elements on a webpage. However, there are key differences between the two:</p>
<ul>
<li><p>Use the "id" attribute when you need to uniquely identify a single element.</p>
</li>
<li><p>Use the "class" attribute when you want to group multiple elements together and apply styling or functionality to them collectively.</p>
</li>
</ul>
<p>While both attributes can be used for styling, the "id" attribute is more suitable for unique styling, while the "class" attribute is ideal for applying consistent styles to multiple elements.</p>
<h3 id="heading-src-source-attribute">src (source) Attribute</h3>
<p>It specifies the source URL of an image to be displayed. Example:</p>
<pre><code class="lang-html"><span class="hljs-tag">&lt;<span class="hljs-name">img</span> <span class="hljs-attr">src</span>=<span class="hljs-string">"image.jpg"</span> <span class="hljs-attr">alt</span>=<span class="hljs-string">"Nuel Cas Photo"</span>&gt;</span>
</code></pre>
<p><strong>Note</strong>: The <code>alt</code> attribute is used to provide alternative text for an image if the image fails to load. It serves as a descriptive text that is displayed in place of the image, helping users understand the content or purpose of the image even when it's not visible.</p>
<h3 id="heading-href-attribute-for-links">href Attribute (for links)</h3>
<p>It specifies the URL that the hyperlink points to. Example:</p>
<pre><code class="lang-html"><span class="hljs-tag">&lt;<span class="hljs-name">a</span> <span class="hljs-attr">href</span>=<span class="hljs-string">"https://www.nuelcas.com"</span>&gt;</span>Visit Nuel Cas<span class="hljs-tag">&lt;/<span class="hljs-name">a</span>&gt;</span>
</code></pre>
<h3 id="heading-width-and-height-attribute-for-images">width and height Attribute (for images)</h3>
<p>It determines the width and height of an image in pixels. Example:</p>
<pre><code class="lang-html"><span class="hljs-tag">&lt;<span class="hljs-name">img</span> <span class="hljs-attr">src</span>=<span class="hljs-string">"image.jpg"</span> <span class="hljs-attr">alt</span>=<span class="hljs-string">"Nuel Cas Photo"</span> <span class="hljs-attr">width</span>=<span class="hljs-string">"400"</span> <span class="hljs-attr">height</span>=<span class="hljs-string">"300"</span>&gt;</span>
</code></pre>
<h3 id="heading-style-attribute">style Attribute</h3>
<p>Allows you to apply inline CSS styles to an HTML element. Example:</p>
<pre><code class="lang-html"><span class="hljs-tag">&lt;<span class="hljs-name">p</span> <span class="hljs-attr">style</span>=<span class="hljs-string">"color: red; font-size: 18px;"</span>&gt;</span>This is a red text.<span class="hljs-tag">&lt;/<span class="hljs-name">p</span>&gt;</span>
</code></pre>
<h3 id="heading-disabled-attribute-for-form-elements">disabled Attribute (for form elements)</h3>
<p>Allows you to disable user interaction with form element. Example:</p>
<pre><code class="lang-html"><span class="hljs-tag">&lt;<span class="hljs-name">input</span> <span class="hljs-attr">type</span>=<span class="hljs-string">"text"</span> <span class="hljs-attr">disabled</span>&gt;</span>
</code></pre>
<h3 id="heading-type-attribute-for-form-element-and-list-items">type Attribute (for form element and list items)</h3>
<p>You can use the <code>type</code> attribute with the <code>&lt;ol&gt;</code> tag to change the numbering style. Example:</p>
<pre><code class="lang-html"><span class="hljs-tag">&lt;<span class="hljs-name">ol</span> <span class="hljs-attr">type</span>=<span class="hljs-string">"A"</span>&gt;</span>
  <span class="hljs-tag">&lt;<span class="hljs-name">li</span>&gt;</span>Item A<span class="hljs-tag">&lt;/<span class="hljs-name">li</span>&gt;</span>
  <span class="hljs-tag">&lt;<span class="hljs-name">li</span>&gt;</span>Item B<span class="hljs-tag">&lt;/<span class="hljs-name">li</span>&gt;</span>
  <span class="hljs-tag">&lt;<span class="hljs-name">li</span>&gt;</span>Item C<span class="hljs-tag">&lt;/<span class="hljs-name">li</span>&gt;</span>
<span class="hljs-tag">&lt;/<span class="hljs-name">ol</span>&gt;</span>
</code></pre>
<p>This will render as:</p>
<pre><code class="lang-text">A. Item A
B. Item B
C. Item C
</code></pre>
<p>Also, you can use <code>type</code> attribute to specify the input type of form element. Say you want to notify the browser that this input is for password, use the code below</p>
<pre><code class="lang-python">&lt;input type=<span class="hljs-string">"password"</span> name=<span class="hljs-string">"password"</span> placeholder=<span class="hljs-string">"Enter your password"</span>&gt;
</code></pre>
<h3 id="heading-name-attribute-for-form-element">name attribute (for form element)</h3>
<p>The <code>name</code> attribute provides a unique identifier for each form field. When the form is submitted to the server, the data entered into each field is sent with the corresponding name as a <em>key-value</em> pair. The code snippet below shows that you want the server to identify this input as email.</p>
<pre><code class="lang-python"> &lt;input type=<span class="hljs-string">"email"</span> id=<span class="hljs-string">"email"</span> name=<span class="hljs-string">"email"</span> placeholder=<span class="hljs-string">"Enter your email"</span>&gt;
</code></pre>
<p><strong>Note</strong>: Understanding and using attributes effectively is essential for controlling the appearance and behavior of elements in your HTML documents.</p>
<h2 id="heading-html-multimedia">HTML Multimedia</h2>
<p>You may need to integrate various types of media content into web pages, such as images, audio, and video. These media elements enhance the user experience by making web content more engaging and dynamic.</p>
<p>Here are the different types of multimedia you can use in HTML:</p>
<h3 id="heading-images">Images</h3>
<p>Images are the most common type of multimedia in HTML. You can add images to a web page using the <code>&lt;img&gt;</code> tag. Example:</p>
<pre><code class="lang-html"><span class="hljs-tag">&lt;<span class="hljs-name">img</span> <span class="hljs-attr">src</span>=<span class="hljs-string">"image.jpg"</span> <span class="hljs-attr">alt</span>=<span class="hljs-string">"Description of the image"</span> <span class="hljs-attr">width</span>=<span class="hljs-string">"200"</span> <span class="hljs-attr">height</span>=<span class="hljs-string">"150"</span>&gt;</span>
</code></pre>
<p>In the above example, <code>src</code> specifies the source URL of the image, <code>alt</code> provides alternative text for accessibility and SEO, and <code>width</code> and <code>height</code> are optional attributes to set the dimensions of the image.</p>
<h3 id="heading-audio">Audio</h3>
<p>You can embed audio files directly into a web page using the <code>&lt;audio&gt;</code> tag. This allows you to play audio clips, music, or other sound recordings. Example:</p>
<pre><code class="lang-html"><span class="hljs-tag">&lt;<span class="hljs-name">audio</span> <span class="hljs-attr">controls</span>&gt;</span>
  <span class="hljs-tag">&lt;<span class="hljs-name">source</span> <span class="hljs-attr">src</span>=<span class="hljs-string">"audio.mp3"</span> <span class="hljs-attr">type</span>=<span class="hljs-string">"audio/mpeg"</span>&gt;</span>
  Your browser may not support the audio element.
<span class="hljs-tag">&lt;/<span class="hljs-name">audio</span>&gt;</span>
</code></pre>
<p>In the above example, <code>controls</code> provides play, pause, and volume controls for the user, <code>src</code>specifies the source URL of the audio file, while <code>type</code> specifies the <a target="_blank" href="https://en.wikipedia.org/wiki/MIME">MIME</a> (Multipurpose Internet Mail Extensions) type of the audio file.</p>
<h3 id="heading-video">Video</h3>
<p>The <code>&lt;video&gt;</code> tag is used to embed video files into a web page. This allows you to play videos within the content. Example:</p>
<pre><code class="lang-html"><span class="hljs-tag">&lt;<span class="hljs-name">video</span> <span class="hljs-attr">controls</span> <span class="hljs-attr">width</span>=<span class="hljs-string">"640"</span> <span class="hljs-attr">height</span>=<span class="hljs-string">"360"</span>&gt;</span>
  <span class="hljs-tag">&lt;<span class="hljs-name">source</span> <span class="hljs-attr">src</span>=<span class="hljs-string">"video.mp4"</span> <span class="hljs-attr">type</span>=<span class="hljs-string">"video/mp4"</span>&gt;</span>
  Your browser may not support the video element.
<span class="hljs-tag">&lt;/<span class="hljs-name">video</span>&gt;</span>
</code></pre>
<p>In the above example, <code>controls</code> provides play, pause, and volume controls for the user, <code>width</code> and <code>height</code> specifies the dimensions of the video, <code>src</code> specifies the source URL of the video file, while <code>type</code> specifies the MIME type of the video file.</p>
<h3 id="heading-iframe">iframe</h3>
<p><code>&lt;iframe&gt;</code> allows you to display content from a different source or page inside a frame on your webpage. This can be useful for embedding videos, maps, web pages, or other external content. Example using <code>&lt;iframe&gt;</code> to embed a video from YouTube:</p>
<pre><code class="lang-html"><span class="hljs-tag">&lt;<span class="hljs-name">iframe</span> 
  <span class="hljs-attr">src</span>=<span class="hljs-string">"https://www.youtube.com/embed/VIDEO_ID"</span> 
  <span class="hljs-attr">width</span>=<span class="hljs-string">"560"</span> 
  <span class="hljs-attr">height</span>=<span class="hljs-string">"315"</span> 
  <span class="hljs-attr">title</span>=<span class="hljs-string">"YouTube Video"</span> 
  <span class="hljs-attr">frameborder</span>=<span class="hljs-string">"0"</span> 
  <span class="hljs-attr">allowfullscreen</span>&gt;</span>
<span class="hljs-tag">&lt;/<span class="hljs-name">iframe</span>&gt;</span>
</code></pre>
<p>In the above code snippet, <code>src</code> attribute specifies the URL of the page or content you want to embed. Sizes are controlled using the <code>width</code> and <code>height</code> attributes. <code>title</code> attribute provides a description for the content, which is important for accessibility.</p>
<p>The <code>frameborder</code> attribute controls whether the iframe has a border (0 for no border, 1 for a border), while the <code>allowfullscreen</code> attribute allows the video to be played in full-screen mode.</p>
<p><strong>Note</strong>: Replace <code>"VIDEO_ID"</code> with the ID of the YouTube video you want to embed.</p>
<h2 id="heading-best-practices">Best Practices</h2>
<ol>
<li>Follow proper HTML document structure:</li>
</ol>
<ul>
<li><p>Start your HTML document with a <code>&lt;!DOCTYPE html&gt;</code> declaration to ensure browser compatibility and standards compliance.</p>
</li>
<li><p>Always include the <code>&lt;html&gt;</code>, <code>&lt;head&gt;</code>, and <code>&lt;body&gt;</code> tags in your document.</p>
</li>
<li><p>Use the <code>&lt;meta charset="UTF-8"&gt;</code> tag to specify the character encoding of your document.</p>
</li>
<li><p>Define the language of your document using the language (<code>&lt;html lang="en"&gt;</code>) attribute.</p>
</li>
<li><p>Include a descriptive title (<code>&lt;title&gt;</code>) tag within the head (<code>&lt;head&gt;</code>) section to provide context for the page.</p>
</li>
</ul>
<ol start="2">
<li>Use semantic HTML element:</li>
</ol>
<ul>
<li>Utilize semantic HTML elements like <code>&lt;header&gt;</code>, <code>&lt;nav&gt;</code>, <code>&lt;main&gt;</code>, <code>&lt;section&gt;</code>, <code>&lt;article&gt;</code>, <code>&lt;aside&gt;</code>, and <code>&lt;footer&gt;</code> to provide clarity and structure to your content. Semantic elements improve accessibility, SEO, and maintainability of your code.</li>
</ul>
<ol start="3">
<li>Comment your code:</li>
</ol>
<ul>
<li>Use comments <code>&lt;!-- --&gt;</code> to document your HTML code, explaining its purpose and functionality. Comments improve code readability and facilitate collaboration among developers.</li>
</ul>
<ol start="4">
<li>Structure your content with proper tags:</li>
</ol>
<ul>
<li><p>Use heading tags <code>&lt;h1&gt;</code> to <code>&lt;h6&gt;</code> for defining the hierarchy of your content.</p>
</li>
<li><p>Utilize paragraph tags <code>&lt;p&gt;</code> to separate blocks of text into distinct paragraphs.</p>
</li>
<li><p>Employ lists (<code>&lt;ul&gt;</code>, <code>&lt;ol&gt;</code>, <code>&lt;li&gt;</code>) to organize and structure content in a hierarchical manner.</p>
</li>
</ul>
<ol start="5">
<li>Group elements with <code>&lt;div&gt;</code> and <code>&lt;span&gt;</code> sparingly:</li>
</ol>
<ul>
<li>Use <code>&lt;div&gt;</code> and <code>&lt;span&gt;</code> tags as needed to group and style elements, but avoid excessive nesting and over-reliance on these elements. Prefer more semantic alternatives where appropriate.</li>
</ul>
<ol start="6">
<li>Do not overuse line breaks (<code>&lt;br&gt;</code>):</li>
</ol>
<ul>
<li>While <code>&lt;br&gt;</code> tags can be useful for simple line breaks, avoid overusing them for layout purposes. Instead, use CSS and block-level elements for more complex layouts to maintain better code readability and maintainability.</li>
</ul>
<ol start="7">
<li>Always use alternative text for images (<code>alt</code> attribute):</li>
</ol>
<ul>
<li>Always include descriptive alternative text using the <code>alt</code> attribute for images (<code>&lt;img&gt;</code> tags). This improves accessibility for users with visual impairments and ensures that content remains understandable even if images fail to load.</li>
</ul>
<ol start="8">
<li>Optimize forms for user experience (UX):</li>
</ol>
<ul>
<li><p>Include meaningful <code>name</code> attributes for form elements to identify and process data accurately on the server.</p>
</li>
<li><p>Utilize appropriate input types (<code>type</code> attribute) for form fields to enhance user experience and ensure data validation.</p>
</li>
<li><p>Use the <code>placeholder</code> attribute to provide hints or expected input for form fields.</p>
</li>
</ul>
<ol start="9">
<li>Ensure compatibility with older browsers:</li>
</ol>
<ul>
<li><p>Your code should undergo <a target="_blank" href="https://www.freecodecamp.org/news/cross-browser-compatibility-testing-best-practices-for-web-developers/">compatibility testing</a> across different browsers and devices to ensure consistent rendering and functionality.</p>
</li>
<li><p>Include appropriate fallbacks for newer HTML features or attributes, this will help maintain compatibility with older browsers.</p>
</li>
</ul>
<ol start="10">
<li>Stay updated with HTML standards:</li>
</ol>
<ul>
<li>Keep yourself updated with the latest HTML standards and best practices to leverage new features, improve performance, and enhance the user experience of your web applications.</li>
</ul>
<p>By adhering to these best practices, you can create well-structured, accessible, and maintainable HTML code that contributes to the overall quality and usability of your web projects.</p>
<h4 id="heading-if-you-have-read-enjoyed-and-desire-more-of-this-piece-feel-free-to-reach-out-to-me-on-xhttpstwittercomcaswebdev-and-linkedinhttpswwwlinkedincomincasmir-onyekani-for-further-collaboration">If you have read, enjoyed, and desire more of this piece, feel free to reach out to me on <a target="_blank" href="https://twitter.com/casweb_dev">X</a> and <a target="_blank" href="https://www.linkedin.com/in/casmir-onyekani/">LinkedIn</a> for further collaboration.</h4>


                        </section>
                        
                            <div class="sidebar">
                                
                                    
                                    <script>var localizedAdText = "ADVERTISEMENT";</script>
                                
                            </div>
                        
                    </div>
                    <hr>
                    
                        <div class="post-full-author-header" data-test-label="author-header-with-bio">
                            
                                
    
    
    

    <section class="author-card" data-test-label="author-card">
        
            
    <img srcset="https://cdn.hashnode.com/res/hashnode/image/upload/v1729274510229/f4288580-9987-4eed-b3e2-5778f8b30671.jpeg?w=500&h=500&fit=crop&crop=entropy&auto=compress,format&format=webp 60w" sizes="60px" src="https://cdn.hashnode.com/res/hashnode/image/upload/v1729274510229/f4288580-9987-4eed-b3e2-5778f8b30671.jpeg?w=500&h=500&fit=crop&crop=entropy&auto=compress,format&format=webp" class="author-profile-image" alt="Casmir Onyekani" width="3448" height="3772" onerror="this.style.display='none'" loading="lazy" data-test-label="profile-image">
  
        

        <section class="author-card-content ">
            <span class="author-card-name">
                <a href="/news/author/Casmir/" data-test-label="profile-link">
                    
                        Casmir Onyekani
                    
                </a>
            </span>
            
                
                    <p data-test-label="author-bio">I am a Software Developer who is so passionate about teaching and writing.
</p>
                
            
        </section>
    </section>

                            
                        </div>
                        <hr>
                    

                    
                    
                        
    


<p data-test-label="social-row-cta" class="social-row">
    If you read this far, thank the author to show them you care. <button id="tweet-btn" class="cta-button" data-test-label="tweet-button">Say Thanks</button>
</p>


    
    <script>document.addEventListener("DOMContentLoaded",(()=>{const t=document.getElementById("tweet-btn"),e=window.location,n="HTML%20for%20Beginners%20%E2%80%93%20HTML%20Basics%20With%20Code%20Examples".replace(/&#39;/g,"%27"),o="",i="@casweb_dev",r=Boolean("");let s;if(r&&(o||i)){const t={originalPostAuthor:"",currentPostAuthor:"Casmir Onyekani"};s=encodeURIComponent(`Thank you ${o||t.originalPostAuthor} for writing this helpful article, and ${i||t.currentPostAuthor} for translating it.`)}else!r&&i&&(s=encodeURIComponent(`Thank you ${i} for writing this helpful article.`));const a=`window.open(\n    '${s?`https://x.com/intent/post?text=${s}%0A%0A${n}%0A%0A${e}`:`https://x.com/intent/post?text=${n}%0A%0A${e}`}',\n    'share-twitter',\n    'width=550, height=235'\n  ); return false;`;t.setAttribute("onclick",a)}));</script>


                        

<div class="learn-cta-row" data-test-label="learn-cta-row">
    <p>
        Learn to code for free. freeCodeCamp's open source curriculum has helped more than 40,000 people get jobs as developers. <a href="https://www.freecodecamp.org/learn/" class="cta-button" id="learn-to-code-cta" rel="noopener noreferrer" target="_blank">Get started</a>
    </p>
</div>

                    
                </section>
                
                    <div class="banner-ad-bottom">
                        
                            

<div class="ad-text" data-test-label="ad-text">ADVERTISEMENT</div>
<div style="display: block; height: auto" id="gam-ad-bottom">
</div>

                        
                    </div>
                
            </article>
        </div>
    </main>


            


<footer class="site-footer">
    <div class="footer-top">
        <div class="footer-desc-col">
            <p data-test-label="tax-exempt-status">freeCodeCamp is a donor-supported tax-exempt 501(c)(3) charity organization (United States Federal Tax Identification Number: 82-0779546)</p>
            <p data-test-label="mission-statement">Our mission: to help people learn to code for free. We accomplish this by creating thousands of videos, articles, and interactive coding lessons - all freely available to the public.</p>
            <p data-test-label="donation-initiatives">Donations to freeCodeCamp go toward our education initiatives, and help pay for servers, services, and staff.</p>
            <p class="footer-donation" data-test-label="donate-text">
                You can <a href="https://www.freecodecamp.org/donate/" class="inline" rel="noopener noreferrer" target="_blank">make a tax-deductible donation here</a>.
            </p>
        </div>
        <div class="trending-guides" data-test-label="trending-guides">
            <h2 id="trending-guides" class="col-header">Trending Books and Handbooks</h2>
            <ul class="trending-guides-articles" aria-labelledby="trending-guides">
                <li>
                    <a href="https://www.freecodecamp.org/news/build-consume-and-document-a-rest-api/" rel="noopener noreferrer" target="_blank">REST APIs
                    </a>
                </li>
                <li>
                    <a href="https://www.freecodecamp.org/news/how-to-write-clean-code/" rel="noopener noreferrer" target="_blank">Clean Code
                    </a>
                </li>
                <li>
                    <a href="https://www.freecodecamp.org/news/learn-typescript-with-react-handbook/" rel="noopener noreferrer" target="_blank">TypeScript
                    </a>
                </li>
                <li>
                    <a href="https://www.freecodecamp.org/news/learn-javascript-for-beginners/" rel="noopener noreferrer" target="_blank">JavaScript
                    </a>
                </li>
                <li>
                    <a href="https://www.freecodecamp.org/news/how-to-build-an-ai-chatbot-with-redis-python-and-gpt/" rel="noopener noreferrer" target="_blank">AI Chatbots
                    </a>
                </li>
                <li>
                    <a href="https://www.freecodecamp.org/news/command-line-for-beginners/" rel="noopener noreferrer" target="_blank">Command Line
                    </a>
                </li>
                <li>
                    <a href="https://www.freecodecamp.org/news/building-consuming-and-documenting-a-graphql-api/" rel="noopener noreferrer" target="_blank">GraphQL APIs
                    </a>
                </li>
                <li>
                    <a href="https://www.freecodecamp.org/news/complete-guide-to-css-transform-functions-and-properties/" rel="noopener noreferrer" target="_blank">CSS Transforms
                    </a>
                </li>
                <li>
                    <a href="https://www.freecodecamp.org/news/how-to-build-scalable-access-control-for-your-web-app/" rel="noopener noreferrer" target="_blank">Access Control
                    </a>
                </li>
                <li>
                    <a href="https://www.freecodecamp.org/news/rest-api-design-best-practices-build-a-rest-api/" rel="noopener noreferrer" target="_blank">REST API Design
                    </a>
                </li>
                <li>
                    <a href="https://www.freecodecamp.org/news/the-php-handbook/" rel="noopener noreferrer" target="_blank">PHP
                    </a>
                </li>
                <li>
                    <a href="https://www.freecodecamp.org/news/the-java-handbook/" rel="noopener noreferrer" target="_blank">Java
                    </a>
                </li>
                <li>
                    <a href="https://www.freecodecamp.org/news/learn-linux-for-beginners-book-basic-to-advanced/" rel="noopener noreferrer" target="_blank">Linux
                    </a>
                </li>
                <li>
                    <a href="https://www.freecodecamp.org/news/react-for-beginners-handbook/" rel="noopener noreferrer" target="_blank">React
                    </a>
                </li>
                <li>
                    <a href="https://www.freecodecamp.org/news/learn-continuous-integration-delivery-and-deployment/" rel="noopener noreferrer" target="_blank">CI/CD
                    </a>
                </li>
                <li>
                    <a href="https://www.freecodecamp.org/news/the-docker-handbook/" rel="noopener noreferrer" target="_blank">Docker
                    </a>
                </li>
                <li>
                    <a href="https://www.freecodecamp.org/news/learn-golang-handbook/" rel="noopener noreferrer" target="_blank">Golang
                    </a>
                </li>
                <li>
                    <a href="https://www.freecodecamp.org/news/the-python-handbook/" rel="noopener noreferrer" target="_blank">Python
                    </a>
                </li>
                <li>
                    <a href="https://www.freecodecamp.org/news/get-started-with-nodejs/" rel="noopener noreferrer" target="_blank">Node.js
                    </a>
                </li>
                <li>
                    <a href="https://www.freecodecamp.org/news/build-crud-operations-with-dotnet-core-handbook/" rel="noopener noreferrer" target="_blank">Todo APIs
                    </a>
                </li>
                <li>
                    <a href="https://www.freecodecamp.org/news/how-to-use-classes-in-javascript-handbook/" rel="noopener noreferrer" target="_blank">JavaScript Classes
                    </a>
                </li>
                <li>
                    <a href="https://www.freecodecamp.org/news/front-end-javascript-development-react-angular-vue-compared/" rel="noopener noreferrer" target="_blank">Front-End Libraries
                    </a>
                </li>
                <li>
                    <a href="https://www.freecodecamp.org/news/the-express-handbook/" rel="noopener noreferrer" target="_blank">Express and Node.js
                    </a>
                </li>
                <li>
                    <a href="https://www.freecodecamp.org/news/python-code-examples-sample-script-coding-tutorial-for-beginners/" rel="noopener noreferrer" target="_blank">Python Code Examples
                    </a>
                </li>
                <li>
                    <a href="https://www.freecodecamp.org/news/clustering-in-python-a-machine-learning-handbook/" rel="noopener noreferrer" target="_blank">Clustering in Python
                    </a>
                </li>
                <li>
                    <a href="https://www.freecodecamp.org/news/an-introduction-to-software-architecture-patterns/" rel="noopener noreferrer" target="_blank">Software Architecture
                    </a>
                </li>
                <li>
                    <a href="https://www.freecodecamp.org/news/what-is-programming-tutorial-for-beginners/" rel="noopener noreferrer" target="_blank">Programming Fundamentals
                    </a>
                </li>
                <li>
                    <a href="https://www.freecodecamp.org/news/learn-to-code-book/" rel="noopener noreferrer" target="_blank">Coding Career Preparation
                    </a>
                </li>
                <li>
                    <a href="https://www.freecodecamp.org/news/become-a-full-stack-developer-and-get-a-job/" rel="noopener noreferrer" target="_blank">Full-Stack Developer Guide
                    </a>
                </li>
                <li>
                    <a href="https://www.freecodecamp.org/news/learn-python-for-javascript-developers-handbook/" rel="noopener noreferrer" target="_blank">Python for JavaScript Devs
                    </a>
                </li>
            </ul>
            <div class="spacer" style="padding: 15px 0;"></div>
            <div>
                <h2 id="mobile-app" class="col-header">
                    Mobile App
                </h2>
                <div class="min-h-[1px] px-[15px] md:w-2/3 md:ml-[16.6%]">
                    <ul aria-labelledby="mobile-app" class="mobile-app-container">
                        <li>
                            <a href="https://apps.apple.com/us/app/freecodecamp/id6446908151?itsct=apps_box_link&itscg=30200" rel="noopener noreferrer" target="_blank">
                                <img src="https://cdn.freecodecamp.org/platform/universal/apple-store-badge.svg" lang="en" alt="Download on the App Store">
                            </a>
                        </li>
                        <li>
                            <a href="https://play.google.com/store/apps/details?id=org.freecodecamp" rel="noopener noreferrer" target="_blank">
                                <img src="https://cdn.freecodecamp.org/platform/universal/google-play-badge.svg" lang="en" alt="Get it on Google Play">
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="footer-bottom">
        <h2 class="col-header" data-test-label="our-nonprofit">Our Charity</h2>
        <div class="our-nonprofit">
             
                <span data-test-label="powered-by">
                    Publication powered by Hashnode
                </span>
            
            <a href="https://www.freecodecamp.org/news/about/" rel="noopener noreferrer" target="_blank" data-test-label="about">
                About
            </a>
            <a href="https://www.linkedin.com/school/free-code-camp/people/" rel="noopener noreferrer" target="_blank" data-test-label="alumni">
                Alumni Network
            </a>
            <a href="https://github.com/freeCodeCamp/" rel="noopener noreferrer" target="_blank" data-test-label="open-source">
                Open Source
            </a>
            <a href="https://www.freecodecamp.org/news/shop/" rel="noopener noreferrer" target="_blank" data-test-label="shop">
                Shop
            </a>
            <a href="https://www.freecodecamp.org/news/support/" rel="noopener noreferrer" target="_blank" data-test-label="support">
                Support
            </a>
            <a href="https://www.freecodecamp.org/news/sponsors/" rel="noopener noreferrer" target="_blank" data-test-label="sponsors">
                Sponsors
            </a>
            <a href="https://www.freecodecamp.org/news/academic-honesty-policy/" rel="noopener noreferrer" target="_blank" data-test-label="honesty">
                Academic Honesty
            </a>
            <a href="https://www.freecodecamp.org/news/code-of-conduct/" rel="noopener noreferrer" target="_blank" data-test-label="coc">
                Code of Conduct
            </a>
            <a href="https://www.freecodecamp.org/news/privacy-policy/" rel="noopener noreferrer" target="_blank" data-test-label="privacy">
                Privacy Policy
            </a>
            <a href="https://www.freecodecamp.org/news/terms-of-service/" rel="noopener noreferrer" target="_blank" data-test-label="tos">
                Terms of Service
            </a>
            <a href="https://www.freecodecamp.org/news/copyright-policy/" rel="noopener noreferrer" target="_blank" data-test-label="copyright">
                Copyright Policy
            </a>
        </div>
    </div>
</footer>

        </div>

        
        
        

        
        
    <script defer src="https://static.cloudflareinsights.com/beacon.min.js/vcd15cbe7772f49c399c6a5babf22c1241717689176015" integrity="sha512-ZpsOmlRQV6y907TI0dKBHq9Md29nnaEIPlkf84rnaERnq6zvWvPUqr2ft8M1aS28oN72PdrCzSjY4U6VaAw1EQ==" data-cf-beacon='{"rayId":"9424d7d2bb0d772e","serverTiming":{"name":{"cfExtPri":true,"cfL4":true,"cfSpeedBrain":true,"cfCacheStatus":true}},"version":"2025.4.0-1-g37f21b1","token":"bdb993c6dde44e178aabd9555e75e4f4"}' crossorigin="anonymous"></script>
</body>
</html>
"""
